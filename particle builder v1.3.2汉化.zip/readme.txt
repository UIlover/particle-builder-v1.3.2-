current version 1.3.2
bug fixes: 
   -write plist file failed , which cause error when open it again.    - fixed.
feature:
   - be able to adjust background color 
2012/12/17
--------------------------------------


old versions:
-version 1.3.0
bug fixes: 
   1.cannot open a plist which [Particle Disgner] created.    - fixed.
   2.not remember last saved dir.	-fixed.

2012/12/13
--------------------------------------
-version 1.2.1 
bug fixes: in release mode, emitter Type box not changed when editor successfully load a plist .
2012/11/16
--------------------------------------
-version 1.2.0 
feature: 
1.add examples, providing an easy way to create a new plist based on the example.
2.user-friendly improvement.

-version 1.1.1
fix bug:
changing maxParticles property causing new particle created.

-version v1.1.0
1.add function : when the duration of particle is not infinite , changing any properties will play the particle.
2.add function : the recent files records can be cleared.
3.fix bug : texture cache not clear.


